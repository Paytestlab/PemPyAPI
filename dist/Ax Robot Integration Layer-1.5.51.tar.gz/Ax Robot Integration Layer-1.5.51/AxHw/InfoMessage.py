#!/usr/bin/python3

class InfoMessage(object):
    """struct of an info message"""

    Major = 0;
    Minor = 0;
    RemoteIpAddress = "";
    MacAddress = [];
    iface = "";
    magic = None;